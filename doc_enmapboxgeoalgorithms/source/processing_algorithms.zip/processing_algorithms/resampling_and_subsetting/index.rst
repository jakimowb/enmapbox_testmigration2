Resampling and Subsetting
=========================

.. toctree::
   :maxdepth: 0
   :glob:

   *
