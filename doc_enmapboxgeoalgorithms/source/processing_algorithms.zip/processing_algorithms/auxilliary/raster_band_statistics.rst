.. _Raster Band Statistics:

**********************
Raster Band Statistics
**********************

This algorithm returns raster band statistics. The output will be shown in the log window and can the copied from there accordingly.

**Parameters**


:guilabel:`Raster` [raster]
    Specify input raster.


:guilabel:`Band` [band]
    Specify input raster band.

