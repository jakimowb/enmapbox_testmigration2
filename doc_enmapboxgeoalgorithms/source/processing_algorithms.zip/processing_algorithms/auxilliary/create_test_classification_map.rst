.. _Create Test Classification Map:

******************************
Create Test Classification Map
******************************

Create a classification map at 30 m resolution by rasterizing the landcover polygons.

**Parameters**

**Outputs**


:guilabel:`Output Classification` [rasterDestination]
    Specify output path for classification raster.

