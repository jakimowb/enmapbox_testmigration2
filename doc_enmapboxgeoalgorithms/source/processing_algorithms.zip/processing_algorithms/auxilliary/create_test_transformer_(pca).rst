.. _Create Test Transformer (PCA):

*****************************
Create Test Transformer (PCA)
*****************************

Create a fitted PCA transformer using enmap testdata.

**Parameters**

**Outputs**


:guilabel:`Output Transformer` [fileDestination]
    Specifiy output path for the transformer (.pkl). This file can be used for applying the transformer to an image using 'Transformation -> Transform Raster' and 'Transformation -> InverseTransform Raster'.

