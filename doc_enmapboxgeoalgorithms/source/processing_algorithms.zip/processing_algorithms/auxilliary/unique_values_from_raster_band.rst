.. _Unique Values from Raster Band:

******************************
Unique Values from Raster Band
******************************

This algorithm returns unique values from a raster band as a list. The output will be shown in the log window and can the copied from there accordingly.

**Parameters**


:guilabel:`Raster` [raster]
    Specify input raster.


:guilabel:`Band` [band]
    Specify input raster band.

