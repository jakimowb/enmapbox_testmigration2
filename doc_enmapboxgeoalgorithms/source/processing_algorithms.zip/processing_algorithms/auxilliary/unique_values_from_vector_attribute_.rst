.. _Unique Values from Vector Attribute :

************************************
Unique Values from Vector Attribute 
************************************

This algorithm returns unique values from vector attributes as a list, which is also usable as Class Definition in other algorithms. The output will be shown in the log window and can the copied from there accordingly.

**Parameters**


:guilabel:`Vector` [vector]
    Specify input vector.


:guilabel:`Field` [field]
    Specify field of vector layer for which unique values should be derived.

