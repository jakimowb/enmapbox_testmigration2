.. _Classification Statistics:

*************************
Classification Statistics
*************************

This algorithm returns class count statistics. The output will be shown in the log window and can the copied from there accordingly.

**Parameters**


:guilabel:`Classification` [raster]
    Specify input raster.

