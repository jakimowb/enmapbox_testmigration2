.. _View Map Metadata:

*****************
View Map Metadata
*****************

Prints all Map metadata to log.

**Parameters**


:guilabel:`Map` [layer]
    undocumented parameter

