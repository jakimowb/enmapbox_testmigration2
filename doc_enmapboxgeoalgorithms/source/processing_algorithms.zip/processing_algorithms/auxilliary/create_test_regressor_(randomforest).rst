.. _Create Test Regressor (RandomForest):

************************************
Create Test Regressor (RandomForest)
************************************

Create a fitted RandomForestRegressor using enmap testdata.

**Parameters**

**Outputs**


:guilabel:`Output Regressor` [fileDestination]
    Specifiy output path for the regressor (.pkl). This file can be used for applying the regressor to an image using 'Regression -> Predict Regression'.

