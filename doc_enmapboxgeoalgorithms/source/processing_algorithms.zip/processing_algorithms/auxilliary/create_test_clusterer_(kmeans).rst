.. _Create Test Clusterer (KMeans):

******************************
Create Test Clusterer (KMeans)
******************************

Create a fitted KMeans clusterer using enmap testdata.

**Parameters**

**Outputs**


:guilabel:`Output Clusterer` [fileDestination]
    Specifiy output path for the clusterer (.pkl). This file can be used for applying the clusterer to an image using 'Clustering -> Predict Clustering'.

