.. _Create Test Fraction Map:

************************
Create Test Fraction Map
************************

Create a fraction map at 30 m resolution by rasterizing the landcover polygons.

**Parameters**

**Outputs**


:guilabel:`Output Fraction` [rasterDestination]
    Specify output path for fraction raster.

