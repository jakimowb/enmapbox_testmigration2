.. _Fraction from Classification:

****************************
Fraction from Classification
****************************

Derive (binarized) class fractions from a classification.

**Parameters**


:guilabel:`Classification` [raster]
    Specify input raster.

**Outputs**


:guilabel:`Output Fraction` [rasterDestination]
    Specify output path for fraction raster.

